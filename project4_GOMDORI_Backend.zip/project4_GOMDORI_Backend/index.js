var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var cors = require('cors');
const { response, request } = require('express');
app.use(cors());
app.use(bodyParser.json());
var mongo = require('mongodb').MongoClient;
var url = 'mongodb://localhost:27017';
//var url = 'mongodb+srv://admin:madcamp@week2.ivjze.mongodb.net/dojo?retryWrites=true&w=majority';

var moment = require('moment');

//moment().add(7, 'd');

function bigTask(callback) {
	setTimeout(() => {
      const result = '큰 일';
      callback(result);
    }, 1000);
}

mongo.connect(url, (err, client)=>{
    if (err)
        console.log('Unable to connect to the mongoDB server.Error',err);
    else{
        

        // register button click    --- CLEAR
        app.post('/register', (request, response)=>{  // id, password, age, gender
            console.log("register start!");
            var id = request.body.id;
            var password = request.body.password;
            var age = request.body.age;
            var gender = request.body.gender;

            var db = client.db('NSM')

            var insertJson = {
                id: id,
                password: password,
                age : age,
                gender : gender
            }

            db.collection('user').find({id:id}).count(function(err, number){
                if (number != 0){
                    response.send("id");
                    console.log("Id already exist");
                }
                else{
                    db.collection('user').insertOne(insertJson, (err, res)=>{
                        console.log("Register success : " + id+ " "+password+ " " + age + " " + gender);
                    })
                    db.createCollection(id+"_calendar");
                    db.createCollection(id+"_fail");
                }
            })
        })
        
        // db 세팅용 push
        app.post('/push', (request, response) =>{
            console.log("push start");
            var id = request.body.id
            var age = request.body.age
            var gender = request.body.gender
            var category = request.body.category
            var label = request.body.label
        
            var insertJson = {
                id : id,
                age : age,
                gender : gender,
                category : category,
                label : label,
            }
            var db = client.db('NSM');
            db.collection('Data').update({age:25}, {age:'25'});
            // db.collection('Data').find(insertJson).count(function(err, number){
            //     if (number == 0){
            //         db.collection('Data').insertOne(insertJson, (err, res)=>{
            //             console.log("push success /"+id+" / "+age+" / "+gender+" / "+category+" / "+label);
            //         })
            //     }
            //     else console.log("already push");
            // })
        })
        // db 세팅용 push
        app.post('/push2', (request, response) =>{

            var date = request.body.date
            var category = request.body.category
            var label = request.body.label

            var insertJson = {
                date : date,
                category : category,
                label : label
            }
            var db = client.db('NSM');
            db.collection('Oct301_fail').find(insertJson).count(function(err, number){
                if (number == 0){
                    var db = client.db('NSM')
                    db.collection('Oct301_fail').insertOne(insertJson, (err, res)=>{
                        console.log("push success"+" / "+date+" / "+category+" / "+label);
                    })
                }
                else console.log("already push");
            })
        })

        // login button click       --- CLEAR
        app.post('/login', (request, response) =>{  // id, password
            console.log("login start");
            var id = request.body.id;
            var password = request.body.password;

            var db = client.db('NSM')

            db.collection('user').find({id:id}).count(function(err, number){
                if (number == 0){
                    response.send("no");
                    console.log("Wrong ID : " + id);
                }
                else{
                    db.collection('user').findOne({id:id}, function(err, user){
                        if (password == user.password){
                            response.json(user);
                            console.log("Login Success : " + id);
                        }
                        else{
                            response.send("no1");
                            console.log("Wrong password");
                        }
                    })
                }
            })
        })
        
        // new schedule insert (TAB2)      --- CLEAR
        app.post('/calendar', (request, response) =>{  // id, date, schedule, time, category
            console.log("new schedule push start");

            var id = request.body.id
            var date = request.body.date
            var schedule = request.body.schedule
            var time = request.body.time

            var category;
            if (request.body.category == "relationship") category = 1;
            else if (request.body.category == "workplace") category = 2;
            else category = 3;
            
            var db = client.db('NSM')

            var insertJson = {
                date : date,
                schedule : schedule,
                time : time,
                category : category
            }
            console.log(id);
            console.log(insertJson);
            db.collection(id+"_calendar").find({date: date, schedule:schedule, time: time}).count(function(err, number){
                if (number != 0){
                    response.send("no");
                    console.log("already exist");
                }
                else{
                    db.collection(id+"_calendar").insertOne(insertJson, (err, res)=>{
                        response.send("yes");
                        console.log("schedule push success");
                    })
                }
            })
        })

        // schedule show (TAB2)
        app.post('/schedule_show', (request, response) =>{  //  id, date
            console.log("schedule_show start");
            var id = request.body.id;
            var date = request.body.date;

            var db = client.db('NSM');
            db.collection(id+"_calendar").find({date:date}, {date:0}).toArray(function(err, us){
                response.json(us);
                console.log(us);
            })
        })

        // TAB1 오늘의 일정 보여주기
        app.post('/daily', (request, response)=>{  // id
            var id = request.body.id;
            
            //var date = request.body.date;
            var date = moment().add(9, 'h').format("MM-DD");
            console.log("daily start "  + id+" "+date + "  /   "+moment().add(9, 'h').format("YYYY-MM-DD HH:mm"));

            var db=client.db('NSM');
            db.collection(id+"_calendar").find({date:date}).toArray(function(err, us){
                response.json(us);
                console.log("TAB1 data list show");
                console.log(us);
            })
        })

        // TAB1 받은 카테고리의 실수 리스트 보여주기
        app.post('/mistake', (request, response)=>{  // id, category
            console.log("mistake start");
            var id = request.body.id;
            var category = request.body.category;
            console.log("id : "+id+" / category : "+category);
            var db = client.db('NSM');
            db.collection('Data').find({id:id, category:category}).toArray(function(err, us){
                response.json(us);
                console.log(us);
            })
        })

        // TAB1 밤. 실수 추가
        app.post('/addMiss', (request, response) =>{  // id, age, gender, category, label
            console.log("TAB1_Add_mistake start");
            var id = request.body.id;
            var age = request.body.age;
            var gender = request.body.gender;
            var category = request.body.category;
            if (category == "대인관계 실수") category = 1;
            else if (category == "일 실수") category = 2;
            else if (category == "스스로 실수") category = 3;
            var label = request.body.label;

            var insertJson = {
                id:id,
                age:age,
                gender:gender,
                category:category,
                label:label,
            }
            console.log(insertJson);
            var db = client.db('NSM');
            db.collection('Data').insertOne(insertJson, (err, res)=>{
                response.send("add");
                console.log("add success");
            })
        })

        // TAB1 밤. 체크한 실수 저장          --- ing....
        app.post('/selectMiss', (request, response) =>{    // id, category, label
            console.log("Add_fail start");
            var id = request.body.id;
            var date = moment().add(9, 'h').format("MM-DD");
            //var category = request.body.category;
            var label = request.body.label;
            console.log("id : "+id+" / label : "+label);
            var db = client.db('NSM');
            db.collection('Data').findOne({id:id, label:label},function(err, us){
                var category = us.category;

                var insertJson = {
                    date : date,
                    category : category,
                    label : label
                }
                console.log(insertJson);
                db.collection(id+"_fail").find(insertJson).count(function(err, number){
                    if (number != 0){
                        response.send("Add_fail already push");
                        console.log("Add_fail already push");
                    }
                    else{
                        db.collection(id+"_fail").insertOne(insertJson, (err, res)=>{
                            response.send("Add_fail push success");
                            console.log("Add_fail push success");
                        })
                    }
                })
            })
        })

        // TAB4. 커뮤니티 원하는 나이대, 성별, 카테고리 받아서 보여주기
        app.post('/show', (request, response) =>{  // age, gender, category
            console.log("TAB4 show start");
            var age = request.body.age;
            var gender = request.body.gender;
            var category = request.body.category;
            if (age != "전체") age = age.substring(0, age.length-1);
            if (category == "대인관계 실수") category = 1;
            else if (category == "일 실수") category = 2;
            else if (category == "스스로 실수") category = 3;
            var findJson={}
            if (age === "전체" && gender === "전체" && category === "전체")
                findJson = {}
            else if (age == "전체" && gender == "전체")
                findJson = {category : category}
            else if (age == "전체" && category == "전체")
                findJson = {gender : gender}
            else if (gender == "전체" && category == "전체")
                findJson = {age : {$gte : age, $lte:age.substring(0, age.length-1)+9}}
            else if (age == "전체")
                findJson = {gender : gender, category : category}
            else if (gender == "전체")
                findJson = {age : {$gte : age, $lte:age.substring(0, age.length-1)+9}, category : category}
            else if (category == "전체")
                findJson = {age : {$gte : age, $lte:age.substring(0, age.length-1)+9}, gender : gender}
            else
                findJson = {age : {$gte : age, $lte:age.substring(0, age.length-1)+9}, gender : gender, category : category}
            console.log(age+" "+gender+" "+category);
            console.log(findJson);
            var db = client.db('NSM')
            db.collection('Data').find(findJson).toArray(function(err, us){
                response.json(us);
                console.log("community show(TAB4)");
                console.log(us);
            })
        })

        // TAB3 chart. 날짜 받아서 모든 category의 fail한 data 개수 리턴
        app.post('/chart', (request, response) =>{   // id, category, date
            var id = request.body.id;
            var category = request.body.category;
            console.log("TAB3 chart start!!! /" + category);
            var date1 = request.body.date1;
            var date2 = request.body.date2;
            var db = client.db('NSM');
            console.log("id:     "+id);
            db.collection(id+"_fail").find({category:category, date:{$gte : date1, $lte:date2}}).count(function(err, number){
                var insertJson = {
                    x : date1+"~"+date2,
                    y : number
                }
                response.json(insertJson);
                console.log(insertJson);
            })
        })

        // app.get('/data', (req, res)=>{
        //     mongo.connect(url, (err, db)=>{
        //         if (err) console.log(err);
        //         else{
        //             var collection = db.collection('user');
        //             collection.find({}).toArray((err, array)=>{
        //                 res.send(array);
        //                 console.log("get");
        //             })
        //         }
        //     })
        // })
        //Start Web Server
        app.listen(80,()=>{
            console.log('Connected to MongoDB Server, Webservice running on port 80!!!');
        })
    }
})

